package com.gruppo2.progetto.model;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "contatti")
public class Contatto {
	
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int idcontatto;
    
	@NotNull(message = "la email deve essere inserita")
	String email;
	
	@NotNull(message = "il numero deve essere inserito")
	String numero_telefono;
    
	String indirizzo;
	
	public Contatto() {
	}
    public Contatto(int idcontatto,String email,String numero_telefono, String indirizzo) {
		this.idcontatto = idcontatto;
		this.email = email;
		this.numero_telefono = numero_telefono;
		this.indirizzo = indirizzo;
	}
    
	public int getIdcontatto() {
		return idcontatto;
	}

	public void setIdcontatto(int idcontatto) {
		this.idcontatto = idcontatto;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getNumero_telefono() {
		return numero_telefono;
	}


	public void setNumero_telefono(String numero_telefono) {
		this.numero_telefono = numero_telefono;
	}


	public String getIndirizzo() {
		return indirizzo;
	}


	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	
	@Override
	public String toString() {
		return "contatto [idcontatto=" + idcontatto + ", email=" + email + ", numero_telefono=" + numero_telefono
				+ ", indirizzo=" + indirizzo + "]";
	}
}
