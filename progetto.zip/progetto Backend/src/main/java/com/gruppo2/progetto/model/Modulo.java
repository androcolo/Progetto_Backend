package com.gruppo2.progetto.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "moduli")
public class Modulo {

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int idmodulo;
    
	@NotNull(message = "il nome deve essere inserito")
	String nome_modulo;
	
	@NotNull(message = "il numero delle ore deve essere inserito")
	int tot_ore;
    
	@NotNull(message = "il professore deve essere inserito")
	int idprofessore;
	
	@NotNull(message = "la categoria deve essere inserita")
	int idcategoria;
	
	public Modulo() {
	}
	
	public Modulo(int idmodulo,String nome_modulo,int tot_ore,int idprofessore,int idcategoria) {
		this.idmodulo = idmodulo;
		this.nome_modulo = nome_modulo;
		this.tot_ore = tot_ore;
		this.idprofessore = idprofessore;
		this.idcategoria = idcategoria;
	}

	public int getIdmodulo() {
		return idmodulo;
	}

	public void setIdmodulo(int idmodulo) {
		this.idmodulo = idmodulo;
	}

	public String getNome_modulo() {
		return nome_modulo;
	}

	public void setNome_modulo(String nome_modulo) {
		this.nome_modulo = nome_modulo;
	}

	public int getTot_ore() {
		return tot_ore;
	}

	public void setTot_ore(int tot_ore) {
		this.tot_ore = tot_ore;
	}

	public int getIdprofessore() {
		return idprofessore;
	}

	public void setIdprofessore(int idprofessore) {
		this.idprofessore = idprofessore;
	}

	public int getIdcategoria() {
		return idcategoria;
	}

	public void setIdcategoria(int idcategoria) {
		this.idcategoria = idcategoria;
	}

	@Override
	public String toString() {
		return "Modulo [idmodulo=" + idmodulo + ", nome_modulo=" + nome_modulo + ", tot_ore=" + tot_ore
				+ ", idprofessore=" + idprofessore + ", idcategoria=" + idcategoria + "]";
	}
}
