package com.gruppo2.progetto.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.gruppo2.progetto.Dao.UtenteDao;
import com.gruppo2.progetto.model.Utente;

@Controller
@RequestMapping(path="/")
public class LoginController {
	@Autowired
	private UtenteDao utenteRepository;	
	@GetMapping("/")
	public String home() {
		return "/index";
	}
	@RequestMapping(value="/", method=RequestMethod.POST)
	public String postLogin(@RequestParam("username") String username, @RequestParam("password") String password, Model model, HttpSession session) {
		Utente utente = utenteRepository.login(username, password);	
		if(utente == null)
			return "redirect:/";
		else {
			String ruolo=utente.getNomeRuolo(utente.getIdruolo());
			session.setAttribute("loggedUser", utente);
	        return "redirect:/"+ruolo+"/";
		}
	}

}
