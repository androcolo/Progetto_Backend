package com.gruppo2.progetto.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.gruppo2.progetto.model.Utente;

@Controller
@RequestMapping(path="/admin")
public class AdminController {
	//@Autowired da aggiungere
	@GetMapping("/")
	public String home(Model model, HttpSession session) {
		System.out.println();
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
		if (utente == null) {
			return "redirect:/";
		}
		model.addAttribute("utente", utente);
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			return "/home";
		}
		else {
			return "redirect:/"+ruolo+"/";
		}

	}
	    	

}
