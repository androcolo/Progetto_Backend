package com.gruppo2.progetto.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "categorie")
public class Categoria {
	
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int idcategoria;
	
	@NotNull(message = "categoria deve esser inserito")
	String categoria;
	
	public Categoria() {
	}

	public Categoria(int idcategoria,String categoria) {
		this.idcategoria = idcategoria;
		this.categoria = categoria;
	}
	
	public int getId() {
		return idcategoria;
	}

	public void setId(int idcategoria) {
		this.idcategoria = idcategoria;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	@Override
	public String toString() {
		return "Categoria [id=" + idcategoria + ", categoria=" + categoria + "]";
	}
	
}
