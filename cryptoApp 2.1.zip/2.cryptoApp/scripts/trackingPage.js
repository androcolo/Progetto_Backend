var url='https://api.coingecko.com/api/v3/coins/markets?vs_currency=Eur&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=1m'
var cryptoList=[];
(function startWebsite(){
    $.ajax({
    url,
    method:'GET',
    dataType:"json",
    success:function(data){
        cryptoList=data
        print_tracking();
    }})
})()

function print_tracking()
{
        tracking_list_pre = []
        market_cap_list =[]
        let crypto_body = document.getElementById('crypto_body')
        for(let c=0; c < cryptoList.length; c++) {                                  
            let perc_color = "green";
            if ( cryptoList[c].price_change_percentage_24h < 0) {
                    perc_color = "red";
            }
            if ( cryptoList[c].price_change_percentage_24h == 0) {
                    perc_color = "black";
            }
            let crypto_info_row = document.createElement("div");
            crypto_info_row.setAttribute("class", "crypto_tracking_row")
            crypto_info_row.innerHTML = `<div class="crypto_cap"> ${cryptoList[c].market_cap_rank} </div>
                                    <div class="crypto_img_box"> <img src="${cryptoList[c].image}" class="crypto_img"> </div> 
                                    <div class="crypto_name_text"> ${cryptoList[c].symbol.toUpperCase()} </div>
                                    <div class="crypto_current_price"> ${(cryptoList[c].current_price).toLocaleString('it-IT', { style: 'currency', currency: 'EUR' })} </div>
                                    <div class="crypto_perc" style = "color: ${perc_color}"> ${cryptoList[c].price_change_percentage_24h.toFixed(2)}% </div>
                                    <div class="crypto_price_change" style = "color: ${perc_color}"> ${cryptoList[c].price_change_24h.toLocaleString('it-IT', { style: 'currency', currency: 'EUR' })}</div>`; 
            crypto_body.appendChild(crypto_info_row)
                                }
}