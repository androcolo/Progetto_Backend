var url='https://api.coingecko.com/api/v3/coins/markets?vs_currency=Eur&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=1m'
var cryptoList=[];
(function startWebsite(){
    $.ajax({
    url,
    method:'GET',
    dataType:"json",
    success:function(data){
        cryptoList=data
        print_tracking();
    }})
})()

function print_tracking()
{
        tracking_list_pre = []
        market_cap_list =[]
        let crypto_body = document.getElementById('crypto_body')
        for(let c=0; c < cryptoList.length; c++) {                                  
            let perc_color = "green";
            if ( cryptoList[c].price_change_percentage_24h < 0) {
                    perc_color = "red";
            }
            if ( cryptoList[c].price_change_percentage_24h == 0) {
                    perc_color = "black";
            }
            let crypto_info_row = document.createElement("div");
            crypto_info_row.setAttribute("class", "crypto_tracking_row")
            crypto_info_row.innerHTML = `<div class="crypto_cap"> ${cryptoList[c].market_cap_rank} </div>
                                    <div class="crypto_img_box"> <img src="${cryptoList[c].image}" class="crypto_img"> </div> 
                                    <div class="crypto_name_text"> ${cryptoList[c].symbol.toUpperCase()} </div>
                                    <div class="crypto_current_price"> ${(cryptoList[c].current_price).toLocaleString('it-IT', { style: 'currency', currency: 'EUR' })} </div>
                                    <div class="crypto_perc" style = "color: ${perc_color}"> ${cryptoList[c].price_change_percentage_24h.toFixed(2)}% </div>
                                    <div class="crypto_price_change" style = "color: ${perc_color}"> ${cryptoList[c].price_change_24h.toLocaleString('it-IT', { style: 'currency', currency: 'EUR' })}</div>`; 
            crypto_body.appendChild(crypto_info_row)
                                }
        sortTable_tracking()       
}

// funziona che ordina la lista in base al marketcap
function sortTable_tracking() {
    var table, rows, switching, i, x, y, shouldSwitch;
    table = document.getElementById("crypto_table");
    switching = true;
    /*Make a loop that will continue until
    no switching has been done:*/
    while (switching) {
      //start by saying: no switching is done:
      switching = false;
      rows = table.rows;
      /*Loop through all table rows (except the
      first, which contains table headers):*/
      for (i = 1; i < (rows.length - 1); i++) {
        //start by saying there should be no switching:
        shouldSwitch = false;
        /*Get the two elements you want to compare,
        one from current row and one from the next:*/
        x =parseInt(rows[i].getElementsByTagName("TD")[0].innerHTML);
        y = parseInt(rows[i + 1].getElementsByTagName("TD")[0].innerHTML);
        //check if the two rows should switch place:
        if (x > y) {
          //if so, mark as a switch and break the loop:
          shouldSwitch = true;
          break;
        }
      }
      if (shouldSwitch) {
        /*If a switch has been marked, make the switch
        and mark that a switch has been done:*/
        rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
        switching = true;
      }
    }
  }

cont = 0;