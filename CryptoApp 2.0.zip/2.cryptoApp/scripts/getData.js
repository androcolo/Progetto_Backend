var mainApp={};
var nameToDisplay="";
var uIdApp="";


(function(){
    var firebase=app_fireBase;
    firebase.auth().onAuthStateChanged(function(user){
    if(user){
        nameToDisplay=user.displayName
        uid=user.uid;
        uIdApp=uid
        localStorage.setItem('uid',uid)
    }
    else{
        uid=null;
        window.location.replace("login.html");
        }
    });
function logOut(){
        firebase.auth().signOut();
    }
mainApp.logOut=logOut;
})()




