const firebaseConfig = {

  apiKey: "AIzaSyDOi0-nK57NPzsD9saecoidLzASfbGFo-A",

  authDomain: "cryptohub-project.firebaseapp.com",

  projectId: "cryptohub-project",

  storageBucket: "cryptohub-project.appspot.com",

  messagingSenderId: "1000768906748",

  appId: "1:1000768906748:web:0104f104d6ff89be4f3e79"

};


firebase.initializeApp(firebaseConfig);
var db = firebase.firestore();