package com.gruppo2.progetto.Dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.AdminModulo;

public interface AdminModuliDao extends CrudRepository<AdminModulo, Long> {
    @Query(value="SELECT * FROM `moduli` \r\n"
            + "WHERE nome_modulo = :nome_modulo ",nativeQuery = true)
    public AdminModulo checkModulo(String nome_modulo);
}