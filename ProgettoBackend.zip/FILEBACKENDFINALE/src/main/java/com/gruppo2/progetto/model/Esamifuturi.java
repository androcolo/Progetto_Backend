package com.gruppo2.progetto.model;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
public class Esamifuturi {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	public int idesame;
	public Esamifuturi(int idesame, String data_ora, String nome_esame, String descrizione, String nome_modulo,
			String nome, String cognome) {
		super();
		this.idesame = idesame;
		this.data_ora = data_ora;
		this.nome_esame = nome_esame;
		this.descrizione = descrizione;
		this.nome_modulo = nome_modulo;
		this.nome = nome;
		this.cognome = cognome;
	}
	public String data_ora;
	public String nome_esame;
	public String descrizione;
	public String nome_modulo;
	public String nome;
	public String cognome;
	public Esamifuturi() {}

}
