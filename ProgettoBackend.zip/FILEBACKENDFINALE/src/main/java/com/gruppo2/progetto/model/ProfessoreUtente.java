package com.gruppo2.progetto.model;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name = "utenti")
public class ProfessoreUtente {
	
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int idutente;
	
	@NotNull(message = "l'username deve essere inserito")
	String username;
	
	@NotNull(message = "la password deve essere inserita")
	String password;
	
	@NotNull(message = "il ruolo deve essere inserito")
	int idruolo;
	
	@NotNull(message = "il contatto deve essere inserito")
	int idcontatto;
	
	public ProfessoreUtente() {}
	
	public ProfessoreUtente(int idutente,String username,String password,int idruolo,int idcontatto) {
		this.idutente = idutente;
		this.username = username;
		this.password = password;
		this.idruolo = idruolo;
		this.idcontatto = idcontatto;
	}

	public int getIdutente() {
		return idutente;
	}

	public void setIdutente(int idutente) {
		this.idutente = idutente;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getIdruolo() {
		return idruolo;
	}
	
	public String getNomeRuolo(int n) {
		String ruolo="";
		if(n==1) {
			ruolo="admin";
		}
		else if(n==2) {
			ruolo="professore";
		}
		else{
			ruolo="studente";
		}
		return ruolo;
	}

	public void setIdruolo(int idruolo) {
		this.idruolo = idruolo;
	}

	public int getIdcontatto() {
		return idcontatto;
	}

	public void setIdcontatto(int idcontatto) {
		this.idcontatto = idcontatto;
	}

	@Override
	public String toString() {
		return "Utente [idutente=" + idutente + ", username=" + username + ", password=" + password + ", idruolo="
				+ idruolo + ", idcontatto=" + idcontatto + "]";
	}
	
}
