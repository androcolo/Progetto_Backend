package com.gruppo2.progetto.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
public class ProfessoreVotoStudente {
	
	public ProfessoreVotoStudente() {};
	
	public ProfessoreVotoStudente(int idstudente, @NotNull String nome, @NotNull String cognome, @NotNull int voto) {
		super();
		this.idstudente = idstudente;
		this.nome = nome;
		this.cognome = cognome;
		this.voto = voto;
	}

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    public int idstudente;

	@NotNull
	public String nome;
	
	@NotNull
	public String cognome;
	
	@NotNull
	public int voto;
}
