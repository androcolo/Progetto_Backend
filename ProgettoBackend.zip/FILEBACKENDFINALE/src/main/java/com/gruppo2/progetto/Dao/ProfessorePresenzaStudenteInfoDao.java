package com.gruppo2.progetto.Dao;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.ProfessorePresenza;
import com.gruppo2.progetto.model.ProfessorePresenzaStudenteInfo;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface ProfessorePresenzaStudenteInfoDao extends CrudRepository<ProfessorePresenzaStudenteInfo, Long> {

    
	/* -------------------------------------------------------------------------- */
	/*                            PRESA PRESENZE LEZIONE                          */
	/* -------------------------------------------------------------------------- */
    
    @Query(value = "SELECT studenti.idstudente,ritardo,uscita_anticipata,nome,cognome,data_nascita,sesso FROM progetto_backend.presenze\r\n"
    		+ "INNER JOIN studenti on studenti.idstudente = presenze.idstudente\r\n"
    		+ "WHERE presenze.idlezione = :idlezione ;",nativeQuery = true)
    public List<ProfessorePresenzaStudenteInfo> GetPresenzeLezioni(int idlezione);
}