package com.gruppo2.progetto.Dao;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.ProfessoreInfoEsamiLezioni;
import com.gruppo2.progetto.model.ProfessoreInfoLezione;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface ProfessoreInfoLezioneDao extends CrudRepository<ProfessoreInfoLezione, Long> {
	
	/* -------------------------------------------------------------------------- */
	/*                          PRESA LISTA ESAMI LEZIONI                         */
	/* -------------------------------------------------------------------------- */

    @Query(value = "	SELECT lezioni.idlezione,professori.nome,professori.cognome,moduli.idmodulo,moduli.nome_modulo,lezioni.nome_lezione,lezioni.descrizione,lezioni.data_ora,lezioni.idclasse,classi.nome_classe FROM progetto_backend.professori\r\n"
    		+ "INNER JOIN moduli on professori.idprofessore = moduli.idprofessore\r\n"
    		+ "INNER JOIN lezioni on lezioni.idmodulo = moduli.idmodulo\r\n"
    		+ "INNER JOIN classi on classi.idclasse = lezioni.idclasse\r\n"
    		+ "WHERE professori.idprofessore = :idprofessore ;",nativeQuery = true)
    public List<ProfessoreInfoLezione> getClasseProfessore(int idprofessore);
    
}