package com.gruppo2.progetto.Dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.AdminCategoria;

public interface AdminCategorieDao extends CrudRepository<AdminCategoria, Long> {
	 @Query(value="SELECT * FROM `categorie` \r\n"
	            + "WHERE categoria = :categoria ",nativeQuery = true)
	    public AdminCategoria checkCategoria(String categoria);
}