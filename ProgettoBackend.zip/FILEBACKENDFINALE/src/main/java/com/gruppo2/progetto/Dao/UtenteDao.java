package com.gruppo2.progetto.Dao;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.Utente;

public interface UtenteDao extends CrudRepository<Utente, Long> {
    List<Utente> findByUsername(String username);
    List<Utente> findByPassword(String password);
    Utente findById(long id);
    
    @Query("select s from Utente s where username= :username and password = :password")
	public Utente login(String username, String password);
    
    @Query(value="SELECT studenti.idstudente FROM progetto_backend.utenti\r\n"
    		+ "inner join studenti on studenti.idutente=utenti.idutente\r\n"
    		+ "where utenti.username=:username",nativeQuery = true)
	public int idStudenteUtente(String username);
    
    @Query(value="SELECT studenti.idstudente FROM progetto_backend.utenti\r\n"
    		+ "inner join studenti on studenti.idutente=utenti.idutente\r\n"
    		+ "where utenti.username=:username",nativeQuery = true)
	public int classeStudenteUtente(String username);
    @Query(value="SELECT idprofessore FROM utenti \r\n"
    		+ "INNER JOIN professori on professori.idutente = utenti.idutente\r\n"
    		+ "WHERE utenti.idutente=:idutente",nativeQuery = true)
    public int GetIdProfessore(int idutente);
    
    
}