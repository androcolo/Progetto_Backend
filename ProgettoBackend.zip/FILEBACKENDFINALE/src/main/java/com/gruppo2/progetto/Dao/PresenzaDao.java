package com.gruppo2.progetto.Dao;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.Presenza;

public interface PresenzaDao extends CrudRepository<Presenza,Long > {
	@Query(value="with prova as (SELECT lezioni.idlezione,lezioni.nome_lezione,lezioni.descrizione,lezioni.data_ora,moduli.nome_modulo,lezioni.idclasse FROM progetto_backend.lezioni inner join moduli on moduli.idmodulo=lezioni.idmodulo\r\n"
    		+ "where lezioni.nome_lezione is not Null and idclasse=:classe),\r\n"
    		+ "provaprova as (SELECT idpresenza,ritardo,uscita_anticipata,idlezione,presenze.idstudente FROM progetto_backend.presenze\r\n"
    		+ "inner join studenti on studenti.idstudente=presenze.idstudente\r\n"
    		+ "where studenti.idstudente=:studente),\r\n"
    		+ "provadisplay as(select  prova.idlezione,prova.nome_modulo,prova.nome_lezione,provaprova.idstudente,prova.data_ora ,provaprova.ritardo,provaprova.uscita_anticipata from prova left join provaprova  on provaprova.idlezione=prova.idlezione)\r\n"
    		+ "select * from provadisplay where provadisplay.data_ora<NOW()",nativeQuery = true)
	public List<Presenza> presenzeStudente(int classe,int studente);
    
}