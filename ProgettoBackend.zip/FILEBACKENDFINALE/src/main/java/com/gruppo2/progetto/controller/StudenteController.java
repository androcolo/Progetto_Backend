package com.gruppo2.progetto.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gruppo2.progetto.Dao.CalendarioDao;
import com.gruppo2.progetto.Dao.EsamifuturiDao;
import com.gruppo2.progetto.Dao.InfoDao;
import com.gruppo2.progetto.Dao.PresenzaDao;
import com.gruppo2.progetto.Dao.UtenteDao;
import com.gruppo2.progetto.Dao.VotiDao;
import com.gruppo2.progetto.model.Calendario;
import com.gruppo2.progetto.model.Esamifuturi;
import com.gruppo2.progetto.model.Informazioni;
import com.gruppo2.progetto.model.Presenza;
import com.gruppo2.progetto.model.Utente;
import com.gruppo2.progetto.model.Voti;

@Controller
@RequestMapping(path="/studente")
public class StudenteController {
	
	@Autowired
	private UtenteDao utenteRepository;	
	@Autowired
	private InfoDao infoRepository;	
	@Autowired
	private VotiDao votiRepository;
	@Autowired
	private CalendarioDao calendarioRepository;
	@Autowired
	private EsamifuturiDao esamifuturiRepository;
	@Autowired
	private PresenzaDao presenzaRepository;
	
	@GetMapping("")
	public String home(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
			if (utente == null) {
				return "redirect:/";
			}
		
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="studente") {
			String username=utente.getUsername();
			List<Calendario> utente_calendario = calendarioRepository.calendarioStudente(utenteRepository.classeStudenteUtente(username));
			model.addAttribute("utente_calendario", utente_calendario);
			model.addAttribute("utente", utente);
			List<Voti> utente_voti = votiRepository.votiStudente(utenteRepository.idStudenteUtente(utente.getUsername()));
			model.addAttribute("utente_voti", utente_voti);
            List<Esamifuturi> utente_esami = esamifuturiRepository.esamiFuturiStudente(utenteRepository.classeStudenteUtente(utente.getUsername()));
            if(utente_esami.size()>0) {
            	model.addAttribute("utente_esami", utente_esami.get(0));
           }
            
			return "/studente/home";
		}
		else {
			return "redirect:/"+ruolo+"/";
		}

	}
	
	@GetMapping("/info")
	public String getProfilo(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="studente") {  
            model.addAttribute("username_utente", utente.getUsername());
            Informazioni utente_info = (Informazioni) infoRepository.infoStudente(utente.getUsername());
            model.addAttribute("info_utente", utente_info);
            return "/studente/info";
		}
		else {
			return "redirect:/"+ruolo;
		}
	}
	@GetMapping("/registro")
	public String getPresenze(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="studente") {
			String username=utente.getUsername();
			List<Presenza> utente_presenze = presenzaRepository.presenzeStudente(utenteRepository.classeStudenteUtente(username),utenteRepository.idStudenteUtente(username));
			model.addAttribute("username_utente", username);
            model.addAttribute("utente_presenze", utente_presenze);
            return "/studente/registro";
		}
		else {
			return "redirect:/"+ruolo;
		}

	}
	@GetMapping("/esami-futuri")
	public String getEsamiFuturi(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="studente") {
			List<Esamifuturi> utente_esami = esamifuturiRepository.esamiFuturiStudente(utenteRepository.classeStudenteUtente(utente.getUsername()));
            model.addAttribute("username_utente", utente.getUsername());
            model.addAttribute("utente_esami", utente_esami);
            return "/studente/esami-futuri";
		}
		else {
			return "redirect:/"+ruolo;
		}

	}
	@GetMapping("/voti")
	public String getVoti(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="studente") {
			List<Voti> utente_voti = votiRepository.votiStudente(utenteRepository.idStudenteUtente(utente.getUsername()));
			model.addAttribute("username_utente", utente.getUsername());
            model.addAttribute("utente_voti", utente_voti);
            return "/studente/voti";
		}
		else {
			return "redirect:/"+ruolo;
		}

	}
	@PostMapping("/voti")
	@ResponseBody
	public List<Voti> getVotiModulo(Model model, HttpSession session,@RequestParam int id) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
		if (utente == null) {
			List<Voti> utente_voti=new ArrayList<>();
            return utente_voti;
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="studente") {
			List<Voti> utente_voti = votiRepository.votiStudenteModulo(utenteRepository.idStudenteUtente(utente.getUsername()),id);
            return utente_voti;
		}
		else {
			List<Voti> utente_voti=new ArrayList<>();
            return utente_voti;
		}

	}
	    	

}
