package com.gruppo2.progetto.Dao;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.ProfessoreInfoLezione;
import com.gruppo2.progetto.model.Professore;
import com.gruppo2.progetto.model.ProfessoreStudente;
import com.gruppo2.progetto.model.ProfessoreUtente;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface ProfessoreDao extends CrudRepository<Professore, Long> {
    Professore findByidprofessore(int id);
   
}