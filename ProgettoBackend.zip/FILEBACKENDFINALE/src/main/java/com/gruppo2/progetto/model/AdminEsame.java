package com.gruppo2.progetto.model;



import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;



import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;



import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;



@Entity
@Table(name = "esami")
public class AdminEsame {
    
    public AdminEsame() {};
    
    public AdminEsame(int idesame, @NotNull String nome_esame, @NotNull String descrizione) {
        super();
        this.idesame = idesame;
        this.nome_esame = nome_esame;
        this.descrizione = descrizione;
    }



   @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    public int idesame;



   @NotNull
    public String nome_esame;
    
    @NotNull
    public String descrizione;
}