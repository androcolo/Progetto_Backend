package com.gruppo2.progetto.Dao;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.Voti;

public interface VotiDao extends CrudRepository<Voti, Long> {
    @Query(value="SELECT voti_esami.idvotoesame,voti_esami.voto, moduli.idmodulo,moduli.nome_modulo ,voti_esami.idstudente, lezioni.data_ora FROM progetto_backend.voti_esami\r\n"
    		+ "    inner join studenti on studenti.idstudente=voti_esami.idstudente\r\n"
    		+ "    inner join esami on esami.idesame=voti_esami.idesame\r\n"
    		+ "    inner join esami_lezioni on esami_lezioni.idesame=voti_esami.idesame\r\n"
    		+ "    inner join lezioni on lezioni.idlezione=esami_lezioni.idlezione\r\n"
    		+ "    inner join moduli on moduli.idmodulo=lezioni.idmodulo\r\n"
    		+ "    group by (voti_esami.idvotoesame) having voti_esami.idstudente=:studente",nativeQuery = true)
	public List<Voti> votiStudente(int studente);
    @Query(value="SELECT  voti_esami.idvotoesame,voti_esami.voto, moduli.idmodulo,moduli.nome_modulo,voti_esami.idstudente,lezioni.data_ora FROM progetto_backend.voti_esami\r\n"
    		+ "    inner join studenti on studenti.idstudente=voti_esami.idstudente\r\n"
    		+ "    inner join esami on esami.idesame=voti_esami.idesame\r\n"
    		+ "    inner join esami_lezioni on esami_lezioni.idesame=voti_esami.idesame\r\n"
    		+ "    inner join lezioni on lezioni.idlezione=esami_lezioni.idlezione\r\n"
    		+ "    inner join moduli on moduli.idmodulo=lezioni.idmodulo\r\n"
    		+ "    group by (voti_esami.idvotoesame) having voti_esami.idstudente=:studente AND moduli.idmodulo=:modulo ",nativeQuery = true)
	public List<Voti> votiStudenteModulo(int studente,int modulo);
}