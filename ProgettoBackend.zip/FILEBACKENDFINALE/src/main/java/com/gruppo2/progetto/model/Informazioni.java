package com.gruppo2.progetto.model;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
public class Informazioni {
	
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int idcontatto;
	
	@NotNull(message = "l'username deve essere inserito")
	String username;
	@NotNull(message = "il nome deve essere inserito")
	String nome;
	@NotNull(message = "il cognome deve essere inserito")
	String cognome;
	@NotNull(message = "la data deve essere inserita")
	String data_nascita;
	@NotNull(message = "la email deve essere inserita")
	String email;
	
	@NotNull(message = "il numero deve essere inserito")
	String numero_telefono;
    
	String indirizzo;
	
	public Informazioni() {
	}
	
    
	public Informazioni(int idcontatto, @NotNull(message = "l'username deve essere inserito") String username,
			@NotNull(message = "il nome deve essere inserito") String nome,
			@NotNull(message = "il cognome deve essere inserito") String cognome,
			@NotNull(message = "la data deve essere inserita") String data_nascita,
			@NotNull(message = "la email deve essere inserita") String email,
			@NotNull(message = "il numero deve essere inserito") String numero_telefono, String indirizzo) {
		this.idcontatto = idcontatto;
		this.username = username;
		this.nome = nome;
		this.cognome = cognome;
		this.data_nascita = data_nascita;
		this.email = email;
		this.numero_telefono = numero_telefono;
		this.indirizzo = indirizzo;
	}


	public int getIdcontatto() {
		return idcontatto;
	}


	public void setIdcontatto(int idcontatto) {
		this.idcontatto = idcontatto;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCognome() {
		return cognome;
	}


	public void setCognome(String cognome) {
		this.cognome = cognome;
	}


	public String getData_nascita() {
		return data_nascita;
	}


	public void setData_nascita(String data_nascita) {
		this.data_nascita = data_nascita;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getNumero_telefono() {
		return numero_telefono;
	}


	public void setNumero_telefono(String numero_telefono) {
		this.numero_telefono = numero_telefono;
	}


	public String getIndirizzo() {
		return indirizzo;
	}


	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}


	
	
}

