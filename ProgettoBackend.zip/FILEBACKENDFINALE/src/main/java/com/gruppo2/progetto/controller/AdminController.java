package com.gruppo2.progetto.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gruppo2.progetto.Dao.AdminDao;
import com.gruppo2.progetto.Dao.AdminCategorieDao;
import com.gruppo2.progetto.Dao.AdminClassiDao;
import com.gruppo2.progetto.Dao.AdminContattiDao;
import com.gruppo2.progetto.Dao.AdminEsamiDao;
import com.gruppo2.progetto.Dao.AdminLezioniDao;
import com.gruppo2.progetto.Dao.AdminModuliDao;
import com.gruppo2.progetto.Dao.AdminProfessoriDao;
import com.gruppo2.progetto.Dao.AdminRuoliDao;
import com.gruppo2.progetto.Dao.AdminStudentiDao;
import com.gruppo2.progetto.Dao.AdminUtenteDao;
import com.gruppo2.progetto.model.AdminCategoria;
import com.gruppo2.progetto.model.AdminClasse;
import com.gruppo2.progetto.model.AdminContatto;
import com.gruppo2.progetto.model.AdminEsame;
import com.gruppo2.progetto.model.AdminLezione;
import com.gruppo2.progetto.model.AdminModulo;
import com.gruppo2.progetto.model.AdminProfessore;
import com.gruppo2.progetto.model.AdminRuolo;
import com.gruppo2.progetto.model.AdminStudente;
import com.gruppo2.progetto.model.Utente;

@Controller
@RequestMapping(path="/admin")
public class AdminController {
	//@Autowired da aggiungere
	@Autowired
	private AdminDao adminRepository;
	@Autowired
	private AdminEsamiDao esamiRepository;
	@Autowired
	private AdminLezioniDao lezioniRepository;
	@Autowired
	private AdminModuliDao moduliRepository;
	@Autowired
	private AdminProfessoriDao professoriRepository;
	@Autowired
	private AdminStudentiDao studentiRepository;
	@Autowired
	private AdminContattiDao contattiRepository;
	@Autowired
	private AdminClassiDao classiRepository;
	@Autowired
	private AdminCategorieDao categorieRepository;
	@Autowired
	private AdminUtenteDao utentiRepository;
	@Autowired
	private AdminRuoliDao ruoliRepository;
	
	@GetMapping("")
	public String home(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			return "/admin/home";
		}
		else {
			return "redirect:/"+ruolo;
		}

	}
	
	@GetMapping("/agg_categoria")
	public String agg_categoria(Model model, HttpSession session) {
		
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			return "/admin/agg_categoria";
		}
		else {
			return "redirect:/"+ruolo;
		}
	}
	//carico tutti i professori e categorie nelle select
	@GetMapping("/agg_modulo")
	public String agg_modulo(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			//popolo la select delle categorie
			List<AdminCategoria> lista_categorie= (List<AdminCategoria>) categorieRepository.findAll();
			model.addAttribute("lista_categorie",lista_categorie);
			//popolo la select dei professori
			List<AdminProfessore> lista_professori= (List<AdminProfessore>) professoriRepository.findAll();
			model.addAttribute("lista_professori",lista_professori);
			return "/admin/agg_modulo";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	
	@GetMapping("/agg_utente")
	public String agg_utente(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			//popolo la select delle categorie
			List<AdminRuolo> lista_ruoli = (List<AdminRuolo>) ruoliRepository.allRuoli();
			model.addAttribute("lista_ruoli",lista_ruoli);
			//popolo la select delle classi
			List<AdminClasse> lista_classi= (List<AdminClasse>) classiRepository.findAll();
			model.addAttribute("lista_classi",lista_classi);
			return "/admin/agg_utente";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	
	@GetMapping("/utenti")
	public String all_utenti(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			List<Utente> lista_utenti= (List<Utente>) utentiRepository.findAll();
			model.addAttribute("lista_utenti",lista_utenti);
			return "/admin/utenti";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	
	@GetMapping("/esami")
	public String all_esami(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			List<AdminEsame> lista_esami= (List<AdminEsame>) esamiRepository.findAll();
			model.addAttribute("lista_esami",lista_esami);
			return "/admin/esami";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	
	@GetMapping("/lezioni")
	public String all_lezioni(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			List<AdminLezione> lista_lezioni= (List<AdminLezione>) lezioniRepository.findAll();
			model.addAttribute("lista_lezioni",lista_lezioni);
			return "/admin/lezioni";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	
	@GetMapping("/moduli")
	public String all_moduli(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			List<AdminModulo> lista_moduli= (List<AdminModulo>) moduliRepository.findAll();
			model.addAttribute("lista_moduli",lista_moduli);
			return "/admin/moduli";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	
	@GetMapping("/professori")
	public String all_professori(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			List<AdminProfessore> lista_professori= (List<AdminProfessore>) professoriRepository.findAll();
			model.addAttribute("lista_professori",lista_professori);
			return "/admin/professori";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	
	@GetMapping("/studenti")
	public String all_studenti(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			List<AdminStudente> lista_studenti= (List<AdminStudente>) studentiRepository.findAll();
			model.addAttribute("lista_studenti",lista_studenti);
			return "/admin/studenti";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	
	@GetMapping("/contatti")
	public String all_contatti(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			List<AdminContatto> lista_contatti= (List<AdminContatto>) contattiRepository.findAll();
			model.addAttribute("lista_contatti",lista_contatti);
			return "/admin/contatti";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	
	@GetMapping("/classi")
	public String all_classi(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			List<AdminClasse> lista_classi= (List<AdminClasse>) classiRepository.findAll();
			model.addAttribute("lista_classi",lista_classi);
			return "/admin/classi";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	
	@GetMapping("/categorie")
	public String all_categorie(Model model,HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="admin") {
			model.addAttribute("utente", utente);
			List<AdminCategoria> lista_categorie= (List<AdminCategoria>) categorieRepository.findAll();
			model.addAttribute("lista_categorie",lista_categorie);
			return "/admin/categorie";
		}
		else {
			return "redirect:/"+ruolo;
		}
		
	}
	//AGGIUNTA CATEGORIA
	@RequestMapping(value="agg_categoria", method=RequestMethod.POST)
    public String AggiuntaCategoria(@RequestParam("categoria") String categoria) {
        AdminCategoria check_categoria = categorieRepository.checkCategoria(categoria);
        if (check_categoria == null) {
            AdminCategoria nuova_categoria = new AdminCategoria();
            nuova_categoria.setCategoria(categoria);
            categorieRepository.save(nuova_categoria);
            return "redirect:/admin/categorie";
        } else {
            System.out.println("Categoria gia' presente");
            return "redirect:/admin/agg_categoria";
        }
    }
    //AGGIUNTA MODULO
    @RequestMapping(value="agg_modulo", method=RequestMethod.POST)
    public String AggiuntaCategoria(@RequestParam("nome_modulo") String nome_modulo,@RequestParam("tot_ore") String tot_ore,
                                    @RequestParam("idprofessore") int idprofessore,@RequestParam("idcategoria") int idcategoria,Model model) {
        AdminModulo check_modulo = moduliRepository.checkModulo(nome_modulo);
        if (check_modulo == null) {
            int totale_ore = Integer.parseInt(tot_ore);
            AdminModulo nuovo_modulo = new AdminModulo();        
            nuovo_modulo.setNome_modulo(nome_modulo);
            nuovo_modulo.setTot_ore(totale_ore);
            nuovo_modulo.setIdprofessore(idprofessore);
            nuovo_modulo.setIdcategoria(idcategoria);
            moduliRepository.save(nuovo_modulo);
            return "redirect:/admin/moduli";
        } else {
            System.out.println("Modulo gia' presente");
            return "redirect:/admin/agg_modulo";
        }
        
    }
	
	//AGGIUNTA PROFESSORE
		@RequestMapping(value="aggiunta_utente_professore", method=RequestMethod.POST)
		@ResponseBody
		
		public void AggiuntaProfessore(@RequestParam("idruolo") int idruolo,@RequestParam("nome") String nome,
				@RequestParam("cognome") String cognome,@RequestParam("data_nascita") String data_nascita,
				@RequestParam("sesso") char sesso,@RequestParam("username") String username,@RequestParam("password") String password,
				@RequestParam("con_password") String con_password,@RequestParam("email") String email,
				@RequestParam("numero_telefono") String numero_telefono,@RequestParam("indirizzo") String indirizzo,Model model) {

			data_nascita = data_nascita.replace("/", "-");
			Utente check_username = utentiRepository.checkUsername(username);
			AdminContatto check_email = contattiRepository.checkEmail(email);
			if (check_username == null & check_email == null) {
				//creazione contatto
				AdminContatto nuovo_contatto = new AdminContatto();
				nuovo_contatto.setEmail(email);
				nuovo_contatto.setNumero_telefono(numero_telefono);
				nuovo_contatto.setIndirizzo(indirizzo);
				contattiRepository.save(nuovo_contatto);
				//prendo l'ultimo contatto aggiunto
				AdminContatto ultimo_contatto = contattiRepository.lastContatto();
				//creazione utente
				Utente nuovo_utente = new Utente();
				nuovo_utente.setUsername(username);
				nuovo_utente.setPassword(password);
				nuovo_utente.setIdruolo(idruolo);
				nuovo_utente.setIdcontatto(ultimo_contatto.getIdcontatto());
				utentiRepository.save(nuovo_utente);
				//prendo l'ultimo utente aggiunto
				Utente ultimo_utente = utentiRepository.lastUtente();
				//creazione Professore
				AdminProfessore nuovo_professore = new AdminProfessore();
				nuovo_professore.setNome(nome);
				nuovo_professore.setCognome(cognome);
				nuovo_professore.setData_nascita(data_nascita);
				nuovo_professore.setSesso(sesso);
				nuovo_professore.setIdutente(ultimo_utente.getIdutente());
				professoriRepository.save(nuovo_professore);				
				
			} else {
				System.out.println("Username o Email gia' presente");
			}
						
		}
		
		//AGGIUNTA STUDENTE
				@RequestMapping(value="aggiunta_utente_studente", method=RequestMethod.POST)
				@ResponseBody
				public void AggiuntaStudente(@RequestParam("idruolo") int idruolo,@RequestParam("nome") String nome,
												@RequestParam("cognome") String cognome,@RequestParam("data_nascita") String data_nascita,
												@RequestParam("sesso") char sesso,@RequestParam("idclasse") int idclasse,
												@RequestParam("username") String username,@RequestParam("password") String password,
												@RequestParam("con_password") String con_password,@RequestParam("email") String email,
												@RequestParam("numero_telefono") String numero_telefono,@RequestParam("indirizzo") String indirizzo,
												Model model) {
					data_nascita = data_nascita.replace("/", "-");
					Utente check_username = utentiRepository.checkUsername(username);
					AdminContatto check_email = contattiRepository.checkEmail(email);
					if (check_username == null & check_email == null) {
						//creazione contatto
						AdminContatto nuovo_contatto = new AdminContatto();
						nuovo_contatto.setEmail(email);
						nuovo_contatto.setNumero_telefono(numero_telefono);
						nuovo_contatto.setIndirizzo(indirizzo);
						contattiRepository.save(nuovo_contatto);
						//prendo l'ultimo contatto aggiunto
						AdminContatto ultimo_contatto = contattiRepository.lastContatto();
						//creazione utente
						Utente nuovo_utente = new Utente();
						nuovo_utente.setUsername(username);
						nuovo_utente.setPassword(password);
						nuovo_utente.setIdruolo(idruolo);
						nuovo_utente.setIdcontatto(ultimo_contatto.getIdcontatto());
						utentiRepository.save(nuovo_utente);
						//prendo l'ultimo utente aggiunto
						Utente ultimo_utente = utentiRepository.lastUtente();
						//creazione Professore
						AdminStudente nuovo_studente = new AdminStudente();
						nuovo_studente.setNome(nome);
						nuovo_studente.setCognome(cognome);
						nuovo_studente.setData_nascita(data_nascita);
						nuovo_studente.setSesso(sesso);
						nuovo_studente.setIdutente(ultimo_utente.getIdutente());
						studentiRepository.save(nuovo_studente);
						
					} else {
						System.out.println("Username o Email gia' presente");
					}
				}
	    	
}
