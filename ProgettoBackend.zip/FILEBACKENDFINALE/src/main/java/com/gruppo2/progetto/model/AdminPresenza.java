package com.gruppo2.progetto.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "presenze")
public class AdminPresenza {
	
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int idpresenza;
    
	int ritardo;
	int uscita_anticipata;
	
	@NotNull(message = "la lezione deve essere inserita")
	int idlezione;
	
	@NotNull(message = "lo studente deve essere inserito")
	int idstudente;
	
	public AdminPresenza() {
	}
	
	public AdminPresenza(int idpresenza, int ritardo, int uscita_anticipata,int idlezione,int idstudente) {
		this.idpresenza = idpresenza;
		this.ritardo = ritardo;
		this.uscita_anticipata = uscita_anticipata;
		this.idlezione = idlezione;
		this.idstudente = idstudente;
	}

	public int getIdpresenza() {
		return idpresenza;
	}

	public void setIdpresenza(int idpresenza) {
		this.idpresenza = idpresenza;
	}

	public int getRitardo() {
		return ritardo;
	}

	public void setRitardo(int ritardo) {
		this.ritardo = ritardo;
	}

	public int getUscita_anticipata() {
		return uscita_anticipata;
	}

	public void setUscita_anticipata(int uscita_anticipata) {
		this.uscita_anticipata = uscita_anticipata;
	}

	public int getIdlezione() {
		return idlezione;
	}

	public void setIdlezione(int idlezione) {
		this.idlezione = idlezione;
	}

	public int getIdstudente() {
		return idstudente;
	}

	public void setIdstudente(int idstudente) {
		this.idstudente = idstudente;
	}

	@Override
	public String toString() {
		return "Presenza [idpresenza=" + idpresenza + ", ritardo=" + ritardo + ", uscita_anticipata="
				+ uscita_anticipata + ", idlezione=" + idlezione + ", idstudente=" + idstudente + "]";
	}
}
