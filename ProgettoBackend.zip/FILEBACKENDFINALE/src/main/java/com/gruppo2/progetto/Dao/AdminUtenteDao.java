package com.gruppo2.progetto.Dao;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.AdminContatto;
import com.gruppo2.progetto.model.Utente;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface AdminUtenteDao extends CrudRepository<Utente, Long> {
    List<Utente> findByUsername(String username);
    List<Utente> findByPassword(String password);
    Utente findById(long id);
    
    @Query("select s from Utente s where username= :username and password = :password")
	public Utente login(String username, String password);
    
    @Query(value="SELECT username,nome,cognome,data_nascita,email,numero_telefono,indirizzo FROM utenti \r\n"
    		+ "inner join studenti on studenti.idutente=utenti.idutente\r\n"
    		+ "inner join classi on classi.idclasse=studenti.idclasse\r\n"
    		+ "inner join contatti on contatti.idcontatto=utenti.idcontatto\r\n"
    		+ "where utenti.username=:username",nativeQuery = true)
	public String infoStudente(String username);
    
    @Query(value="SELECT username,nome,cognome,data_nascita,email,numero_telefono,indirizzo FROM utenti \r\n"
    		+ "inner join professori on professori.idutente=utenti.idutente\r\n"
    		+ "inner join contatti on contatti.idcontatto=utenti.idcontatto\r\n"
    		+ "where utenti.username=:username",nativeQuery = true)
	public String infoProfessore(String username);
    
    //controllo utente
    @Query(value="SELECT * FROM `utenti` \r\n"
    		+ "WHERE username = :username ",nativeQuery = true)
    public Utente checkUsername(String username);
    
  //presa dell'ultimo utente aggiunto
    @Query(value="SELECT * FROM `utenti` ORDER BY idutente DESC LIMIT 1",nativeQuery = true)
 	public Utente lastUtente();
    }