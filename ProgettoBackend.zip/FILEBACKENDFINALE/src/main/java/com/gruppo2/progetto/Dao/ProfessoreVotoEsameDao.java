package com.gruppo2.progetto.Dao;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.ProfessoreVotoEsame;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface ProfessoreVotoEsameDao extends CrudRepository<ProfessoreVotoEsame, Long> {
	     
	/* -------------------------------------------------------------------------- */
	/*                       CONTROLLO DI DOPPIONE VOTO ALUNNO                    */
	/* -------------------------------------------------------------------------- */
   
    @Query(value = "SELECT * FROM progetto_backend.voti_esami\r\n"
    		+ "WHERE idstudente = :idstudente AND idesame=:idesame ;",nativeQuery = true)
    public ProfessoreVotoEsame ControlloVotoAlunno(int idesame,int idstudente);
    
}