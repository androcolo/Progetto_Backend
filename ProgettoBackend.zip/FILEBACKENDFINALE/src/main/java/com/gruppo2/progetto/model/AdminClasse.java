package com.gruppo2.progetto.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "classi")
public class AdminClasse {
	
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    public int idclasse;
    
	@NotNull(message = "nome della classe deve esser inserito")
	String nome_classe;
	
	public AdminClasse() {
	}
	
    public AdminClasse(int idclasse, String nome_classe) {
		this.idclasse = idclasse;
		this.nome_classe = nome_classe;
	}
    
	public int getId() {
		return idclasse;
	}

	public void setId(int idclasse) {
		this.idclasse = idclasse;
	}

	public String getNome_classe() {
		return nome_classe;
	}

	public void setNome_classe(String nome_classe) {
		this.nome_classe = nome_classe;
	}

	@Override
	public String toString() {
		return "Classi [idclasse=" + idclasse + ", nome_classe=" + nome_classe + "]";
	}
	
	
}
