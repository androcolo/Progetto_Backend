package com.gruppo2.progetto.Dao;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.ProfessoreInfoEsamiLezioni;
import com.gruppo2.progetto.model.ProfessoreInfoLezione;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface ProfessoreInfoEsamiLezioniDao extends CrudRepository<ProfessoreInfoEsamiLezioni, Long> {
	
	/* -------------------------------------------------------------------------- */
	/*                       PRESA DATI LEZIONE PROFESSORE                        */
	/* -------------------------------------------------------------------------- */
   
    @Query(value = "SELECT idesamelezione,esami.idesame,lezioni.data_ora,esami.nome_esame,lezioni.idclasse,idprofessore,classi.nome_classe FROM progetto_backend.esami_lezioni\r\n"
    		+ "INNER JOIN esami on esami.idesame = esami_lezioni.idesame\r\n"
    		+ "INNER JOIN lezioni on lezioni.idlezione = esami_lezioni.idlezione\r\n"
    		+ "INNER JOIN moduli on lezioni.idmodulo = moduli.idmodulo\r\n"
    		+ "INNER JOIN classi on lezioni.idclasse = classi.idclasse\r\n"
    		+ "WHERE idprofessore = :idprofessore ;",nativeQuery = true)
    public List<ProfessoreInfoEsamiLezioni> getListaEsamiProfessore(int idprofessore);
    
}