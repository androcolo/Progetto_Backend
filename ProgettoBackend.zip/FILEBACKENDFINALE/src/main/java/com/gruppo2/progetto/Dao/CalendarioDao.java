package com.gruppo2.progetto.Dao;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.Calendario;

public interface CalendarioDao extends CrudRepository<Calendario,Long > {
	@Query(value="SELECT lezioni.idlezione,lezioni.data_ora,moduli.nome_modulo,professori.nome,professori.cognome FROM progetto_backend.lezioni\r\n"
			+ "inner join moduli on moduli.idmodulo=lezioni.idmodulo\r\n"
			+ "inner join professori on professori.idprofessore=moduli.idprofessore\r\n"
			+ "where lezioni.idclasse=:classe ORDER BY (lezioni.data_ora)",nativeQuery = true)
			public List<Calendario> calendarioStudente(int classe);
}