package com.gruppo2.progetto.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.AdminContatto;
import com.gruppo2.progetto.model.Utente;

public interface AdminContattiDao extends CrudRepository<AdminContatto, Long> {
    
 //controllo email
   @Query(value="SELECT * FROM `contatti` \r\n"
   		+ "WHERE email = :email ",nativeQuery = true)
   public AdminContatto checkEmail(String email);
 //presa dell'ultimo contatto aggiunto
   @Query(value="SELECT * FROM `contatti` ORDER BY idcontatto DESC LIMIT 1",nativeQuery = true)
	public AdminContatto lastContatto();
    
}