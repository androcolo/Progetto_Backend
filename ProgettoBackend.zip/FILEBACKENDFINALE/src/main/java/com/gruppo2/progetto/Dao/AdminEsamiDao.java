package com.gruppo2.progetto.Dao;
import java.util.List;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;



import com.gruppo2.progetto.model.AdminEsame;



// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface AdminEsamiDao extends CrudRepository<AdminEsame, Long> {
    
    /* -------------------------------------------------------------------------- */
    /*                       CONTROLLO DI ESAME IN UNA LEZIONE                    */
    /* -------------------------------------------------------------------------- */
   
    @Query(value = "SELECT esami.idesame,esami.nome_esame,esami.descrizione FROM progetto_backend.esami\r\n"
            + "INNER JOIN esami_lezioni on esami.idesame = esami_lezioni.idesame\r\n"
            + "WHERE idlezione = :idlezione ;",nativeQuery = true)
    public AdminEsame ControlloEsameInLezione(int idlezione);
    
}
