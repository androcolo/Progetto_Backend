package com.gruppo2.progetto.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
public class ProfessoreInfoEsamiLezioni {
	
	public ProfessoreInfoEsamiLezioni() {};
	
	public ProfessoreInfoEsamiLezioni(int idesamelezione, @NotNull int idesame, @NotNull String data_ora,
			@NotNull String nome_esame, @NotNull int idclasse, @NotNull int idprofessore, @NotNull String nome_classe) {
		super();
		this.idesamelezione = idesamelezione;
		this.idesame = idesame;
		this.data_ora = data_ora;
		this.nome_esame = nome_esame;
		this.idclasse = idclasse;
		this.idprofessore = idprofessore;
		this.nome_classe = nome_classe;
	};

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    public int idesamelezione;
	
	@NotNull
	public int idesame;
	
	@NotNull
	public String data_ora;
	
	@NotNull
	public String nome_esame;
	
	@NotNull
	public int idclasse;
	
	@NotNull
	public int idprofessore;
	
	@NotNull
	public String nome_classe;
}
