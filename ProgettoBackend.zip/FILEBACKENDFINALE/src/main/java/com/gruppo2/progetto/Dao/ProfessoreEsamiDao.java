package com.gruppo2.progetto.Dao;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.ProfessoreEsame;
import com.gruppo2.progetto.model.ProfessoreInfoLezione;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface ProfessoreEsamiDao extends CrudRepository<ProfessoreEsame, Long> {
	
	@Query(value = "SELECT * FROM progetto_backend.esami\r\n"
			+ "WHERE nome_esame = :nome_esame ;",nativeQuery = true)
	public ProfessoreEsame trovanome_esame(String nome_esame);
    
	/* -------------------------------------------------------------------------- */
	/*                       CONTROLLO DI ESAME IN UNA LEZIONE                    */
	/* -------------------------------------------------------------------------- */
   
    @Query(value = "SELECT esami.idesame,esami.nome_esame,esami.descrizione FROM progetto_backend.esami\r\n"
    		+ "INNER JOIN esami_lezioni on esami.idesame = esami_lezioni.idesame\r\n"
    		+ "WHERE idlezione = :idlezione ;",nativeQuery = true)
    public ProfessoreEsame ControlloEsameInLezione(int idlezione);
    
    
}