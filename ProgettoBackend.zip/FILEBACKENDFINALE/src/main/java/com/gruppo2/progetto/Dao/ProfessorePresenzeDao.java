package com.gruppo2.progetto.Dao;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.ProfessorePresenza;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface ProfessorePresenzeDao extends CrudRepository<ProfessorePresenza, Long> {
	
	/* -------------------------------------------------------------------------- */
	/*                          CONTROLLO DATABASE PRESENZA                       */
	/* -------------------------------------------------------------------------- */
    
    @Query(value = "SELECT * FROM progetto_backend.presenze\r\n"
    		+ "WHERE idlezione = :idlezione AND idstudente = :idstudente ;",nativeQuery = true)
    public ProfessorePresenza getPresenzaDB(int idlezione,int idstudente);
    
    
}