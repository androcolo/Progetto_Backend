package com.gruppo2.progetto.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.gruppo2.progetto.Dao.ProfessoreEsamiDao;
import com.gruppo2.progetto.Dao.ProfessoreEsamiLezioniDao;
import com.gruppo2.progetto.Dao.ProfessoreInfoEsamiLezioniDao;
import com.gruppo2.progetto.Dao.ProfessoreInfoLezioneDao;
import com.gruppo2.progetto.Dao.ProfessoreLezioneDao;
import com.gruppo2.progetto.Dao.ProfessorePresenzaStudenteInfoDao;
import com.gruppo2.progetto.Dao.ProfessorePresenzeDao;
import com.gruppo2.progetto.Dao.InfoDao;
import com.gruppo2.progetto.Dao.ProfessoreDao;
import com.gruppo2.progetto.Dao.ProfessoreStudenteDao;
import com.gruppo2.progetto.Dao.UtenteDao;
import com.gruppo2.progetto.Dao.ProfessoreVotoEsameDao;
import com.gruppo2.progetto.Dao.ProfessoreVotoStudenteDao;
import com.gruppo2.progetto.model.ProfessoreEsame;
import com.gruppo2.progetto.model.ProfessoreEsameLezione;
import com.gruppo2.progetto.model.ProfessoreInfoEsamiLezioni;
import com.gruppo2.progetto.model.ProfessoreInfoLezione;
import com.gruppo2.progetto.model.ProfessoreLezione;
import com.gruppo2.progetto.model.ProfessorePresenza;
import com.gruppo2.progetto.model.ProfessorePresenzaStudenteInfo;
import com.gruppo2.progetto.model.Informazioni;
import com.gruppo2.progetto.model.Professore;
import com.gruppo2.progetto.model.ProfessoreStudente;
import com.gruppo2.progetto.model.ProfessoreUtente;
import com.gruppo2.progetto.model.ProfessoreVotoEsame;
import com.gruppo2.progetto.model.ProfessoreVotoStudente;
import com.gruppo2.progetto.model.Utente;

@Controller
@RequestMapping(path="/professore")
public class ProfessoreController {
	
	@Autowired
	private UtenteDao utenteRepository;	
	@Autowired
	private ProfessoreDao professoreRepository;
	@Autowired
	private ProfessoreInfoLezioneDao infolezioneRepository;
	@Autowired
	private ProfessoreEsamiDao esameRepository;
	@Autowired
	private ProfessoreLezioneDao lezioneRepository;
	@Autowired
	private ProfessoreStudenteDao studenteRepository;
	@Autowired
	private ProfessoreInfoEsamiLezioniDao infoesamilezioniRepository;
	@Autowired
	private ProfessoreVotoStudenteDao votostudenteRepository;
	@Autowired
	private ProfessorePresenzeDao presenzeRepository;
	@Autowired
	private ProfessoreVotoEsameDao votoesameRepository;
	@Autowired
	private ProfessoreEsamiLezioniDao esamelezioneRepository;
	@Autowired
	private ProfessorePresenzaStudenteInfoDao presenzastudentiinfoRepository;
	@Autowired
	private InfoDao infoRepository;
	@GetMapping("")
	public String home(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
			if (utente == null) {
				return "redirect:/";
			}
		
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="professore") {
			model.addAttribute("utente", utente);
            model.addAttribute("username_utente", utente.getUsername());
			return "/professore/home";
		}
		else {
			return "redirect:/"+ruolo;
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*  sezione di redirect alla pagina di info del professore                    */
	/* -------------------------------------------------------------------------- */
	
	@GetMapping("/info")
	public String getProfilo(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="professore") {  
            model.addAttribute("username_utente", utente.getUsername());
            
            Informazioni utente_info = (Informazioni) infoRepository.infoProfessore(utente.getUsername());
            model.addAttribute("info_utente", utente_info);
            return "/professore/info";
		}
		else {
			return "redirect:/"+ruolo;
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*                sezione di redirect alla pagina di appello                  */
	/* -------------------------------------------------------------------------- */
	    	
	@GetMapping("/appello")
	public String appello(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
		if (utente == null) {
			return "redirect:/";
		}
		
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="professore") {
            int idProfessore = utenteRepository.GetIdProfessore(utente.getIdutente()); 
            model.addAttribute("username_utente", utente.getUsername());
            List<ProfessoreInfoLezione> lista_lezioni_disponibili = infolezioneRepository.getClasseProfessore(idProfessore);
            model.addAttribute("lista_lezioni_disponibili", lista_lezioni_disponibili);
            return "/professore/appello";
		}
		else {
			return "redirect:/"+ruolo;
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*         sezione di redirect alla pagina di inserimento presenza            */
	/* -------------------------------------------------------------------------- */
	
	@GetMapping("/appello_classe")
	public String getappello_classe(@RequestParam("idclasse") int idclasse,@RequestParam("idlezione") int idlezione,Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
			
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="professore") {
			int idProfessore = utenteRepository.GetIdProfessore(utente.getIdutente()); 
            model.addAttribute("username_utente", utente.getUsername());
			//presa dati dal db
			ProfessoreEsame controllo_esame_db = esameRepository.ControlloEsameInLezione(idlezione);
			boolean controllo = false;
			model.addAttribute("controllo", controllo);
			List<ProfessoreEsame> nomi_esami_professore = (List<ProfessoreEsame>) esameRepository.findAll();
			model.addAttribute("nomi_esami_professore",nomi_esami_professore);
				if(controllo_esame_db != null) {
					model.addAttribute("esame", controllo_esame_db);
					controllo = true;
					model.addAttribute("controllo", controllo);
				}
			ProfessoreLezione lezione = lezioneRepository.getLezione(idlezione);
			List<ProfessoreStudente> lista_studenti = studenteRepository.getAlunniClasse(idclasse);
			//setting dei dati nel model
			model.addAttribute("lista_studenti", lista_studenti);
			model.addAttribute("idlezione", idlezione);
			model.addAttribute("lezione", lezione);
			//return
            return "/professore/appello_classe";
		}
		else {
			return "redirect:/"+ruolo;
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*         sezione di redirect alla pagina di visualizzazione esami           */
	/* -------------------------------------------------------------------------- */
	
	@GetMapping("/listaesami")
	public String getesami(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
			
		if (utente == null) {
			return "redirect:/";
		}
		if(ruolo=="professore") {
			int idProfessore = utenteRepository.GetIdProfessore(utente.getIdutente()); 
            Professore professore = professoreRepository.findByidprofessore(idProfessore);
            model.addAttribute("professore", professore);
            session.setAttribute("professore", professore);
            List<ProfessoreInfoEsamiLezioni> lista_esami_professore = infoesamilezioniRepository.getListaEsamiProfessore(idProfessore);
            model.addAttribute("lista_esami_professore",lista_esami_professore);
            model.addAttribute("username_utente", utente.getUsername());
			return "/professore/listaesami";
		}
		else {
			return "redirect:/"+ruolo;
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*         sezione di redirect alla pagina di assegnazione voti               */
	/* -------------------------------------------------------------------------- */
	
	@GetMapping("/assegnavoti")
	public String assegnavoti(@RequestParam("idclasse") int idclasse,@RequestParam("nome_esame") String nome_esame,@RequestParam("idesame") int idesame,Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
			
		if (utente == null) {
			return "redirect:/";
		}
		if(ruolo=="professore") {
            List<ProfessoreStudente> lista_alunni_classe = studenteRepository.getAlunniClasse(idclasse);
            model.addAttribute("lista_alunni_classe",lista_alunni_classe);
            model.addAttribute("nome_esame",nome_esame);
            model.addAttribute("idesame",idesame);
            model.addAttribute("username_utente", utente.getUsername());
			return "/professore/assegnavoti";
		}
		else {
			return "redirect:/"+ruolo;
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*         sezione di redirect alla pagina di aggiunta nuovo esame            */
	/* -------------------------------------------------------------------------- */
	
	@GetMapping("/aggiuntaesami")
	public String assegnavoti(Model model, HttpSession session) {
		Utente utente = (Utente) session.getAttribute("loggedUser");
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
			
		if (utente == null) {
			return "redirect:/";
		}
		if(ruolo=="professore") {
            model.addAttribute("username_utente", utente.getUsername());
			return "/professore/aggiuntaesami";
		}
		else {
			return "redirect:/"+ruolo;
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*              POST MAPPING INSERIMENTO ESAME NUOVO PROFESSORE               */
	/* -------------------------------------------------------------------------- */
	
	@RequestMapping(value="/aggiuntaesamedb", method=RequestMethod.POST)
	@ResponseBody
	public void AggiuntaEsameProfessore(@RequestParam("nome_esame") String nome_esame,@RequestParam("descrizione_esame") String descrizione_esame,Model model, HttpSession session){
		ProfessoreEsame controllo_esame = esameRepository.trovanome_esame(nome_esame);
		if (controllo_esame == null) {
			ProfessoreEsame esame_nuovo = new ProfessoreEsame();
			esame_nuovo.setDescrizione(descrizione_esame);
			esame_nuovo.setNome_esame(nome_esame);
			esameRepository.save(esame_nuovo);
		}
		else{
			System.out.println("Esame gia' esistente!");
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*           POST MAPPING INSERIMENTO TUTTI VALORI DELLA PRESENZA             */
	/* -------------------------------------------------------------------------- */
	
	@RequestMapping(value="/tot", method=RequestMethod.POST)
	@ResponseBody
	public void AggiuntaPresenzaTot(@RequestParam("idstudente") int idstudente,@RequestParam("idlezione") int idlezione,@RequestParam("ritardo") String ritardo,@RequestParam("uscita") String uscita,Model model, HttpSession session){
		ProfessorePresenza presenza_controllo = presenzeRepository.getPresenzaDB(idlezione, idstudente);
		if (presenza_controllo == null) {
			ProfessorePresenza presenza = new ProfessorePresenza();
			presenza.setIdstudente(idstudente);
			presenza.setRitardo(ritardo);
			presenza.setIdlezione(idlezione);
			presenza.setUscita_anticipata(uscita);
			presenzeRepository.save(presenza);
		}else {
			presenza_controllo.setRitardo(ritardo);
			presenza_controllo.setUscita_anticipata(uscita);
			presenzeRepository.save(presenza_controllo);
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*           Request Map  INSERIMENTO MINIMO VALORI DELLA PRESENZA            */
	/* -------------------------------------------------------------------------- */
	
	@RequestMapping(value="/min", method=RequestMethod.POST)
	@ResponseBody
	public void AggiuntaPresenzaMin(@RequestParam("idstudente") int idstudente,@RequestParam("idlezione") int idlezione,Model model, HttpSession session){	
		ProfessorePresenza presenza_controllo = presenzeRepository.getPresenzaDB(idlezione, idstudente);
		if (presenza_controllo == null) {
			ProfessorePresenza presenza = new ProfessorePresenza();
			presenza.setIdstudente(idstudente);
			presenza.setIdlezione(idlezione);
			presenzeRepository.save(presenza);
		}// aggiungere un alert
	}
	
	/* -------------------------------------------------------------------------- */
	/*        Request Map INSERIMENTO VALORI + USCITA DELLA PRESENZA             */
	/* -------------------------------------------------------------------------- */
	
	@RequestMapping(value="/usc", method=RequestMethod.POST)
	@ResponseBody
	public void AggiuntaPresenzaUsc(@RequestParam("idstudente") int idstudente,@RequestParam("idlezione") int idlezione,@RequestParam("uscita") String uscita,Model model, HttpSession session){
		ProfessorePresenza presenza_controllo = presenzeRepository.getPresenzaDB(idlezione, idstudente);
		if (presenza_controllo == null) {
			ProfessorePresenza presenza = new ProfessorePresenza();
			presenza.setIdstudente(idstudente);
			presenza.setIdlezione(idlezione);
			presenza.setUscita_anticipata(uscita);
			presenzeRepository.save(presenza);
		}else {
			presenza_controllo.setUscita_anticipata(uscita);
			presenzeRepository.save(presenza_controllo);
		}
	}

	/* -------------------------------------------------------------------------- */
	/*         Request Map INSERIMENTO VALORI + RITARDO DELLA PRESENZA           */
	/* -------------------------------------------------------------------------- */
	
	@RequestMapping(value="/rit", method=RequestMethod.POST)
	@ResponseBody
	public void AggiuntaPresenzaRit(@RequestParam("idstudente") int idstudente,@RequestParam("idlezione") int idlezione,@RequestParam("ritardo") String ritardo,Model model, HttpSession session){
		ProfessorePresenza presenza_controllo = presenzeRepository.getPresenzaDB(idlezione, idstudente);
		if (presenza_controllo == null) {
			ProfessorePresenza presenza = new ProfessorePresenza();
			presenza.setIdstudente(idstudente);
			presenza.setRitardo(ritardo);
			presenza.setIdlezione(idlezione);
			presenzeRepository.save(presenza);
		}else {
			presenza_controllo.setRitardo(ritardo);
			presenzeRepository.save(presenza_controllo);
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*                     Request Map delete presenza dal db                     */
	/* -------------------------------------------------------------------------- */
	
	@RequestMapping(value="/del", method=RequestMethod.POST)
	@ResponseBody
	public void Deletepresenza(@RequestParam("idstudente") int idstudente,@RequestParam("idlezione") int idlezione,Model model, HttpSession session){
		ProfessorePresenza presenza_controllo = presenzeRepository.getPresenzaDB(idlezione, idstudente);
		presenzeRepository.delete(presenza_controllo);
	}
	
	/* -------------------------------------------------------------------------- */
	/*             	Request Map INSERIMENTO VOTI DEGLI ALUNNI                     */
	/* -------------------------------------------------------------------------- */
		
	@RequestMapping(value="/voto", method=RequestMethod.POST)
	@ResponseBody
	public void AssegnazioneVoto(@RequestParam("idstudente") int idstudente,@RequestParam("idesame") int idesame,@RequestParam("voto") int voto,Model model, HttpSession session){
		ProfessoreVotoEsame votoesame_controllo = votoesameRepository.ControlloVotoAlunno(idesame, idstudente);
		if (votoesame_controllo != null) {
			votoesame_controllo.setVoto(voto);
			votoesameRepository.save(votoesame_controllo);
		}else {
			ProfessoreVotoEsame voto_esame = new ProfessoreVotoEsame();
			voto_esame.setIdstudente(idstudente);
			voto_esame.setIdesame(idesame);
			voto_esame.setVoto(voto);
			votoesameRepository.save(voto_esame);
		}
	}
	
	/* -------------------------------------------------------------------------- */
	/*             	Request Map MODIFICA INFO LEZIONE IDLEZIONE                   */
	/* -------------------------------------------------------------------------- */
	
	@RequestMapping(value="/modinfolez", method=RequestMethod.POST)
	@ResponseBody
	public void ModificaInfoLezione(@RequestParam("idlezione") int idlezione,@RequestParam("descrizione_lezione") String descrizione_lezione,@RequestParam("nome_lezione") String nome_lezione,Model model, HttpSession session){
		ProfessoreLezione lezione = lezioneRepository.getLezione(idlezione);
		lezione.setNome_lezione(nome_lezione);
		lezione.setDescrizione(descrizione_lezione);
		lezioneRepository.save(lezione);
	}
	
	/* -------------------------------------------------------------------------- */
	/*             	             ADD ESAME IN LEZIONE                             */
	/* -------------------------------------------------------------------------- */
	
	@RequestMapping(value="/insertesame", method=RequestMethod.POST)
	@ResponseBody
	public void AggiuntaEsameDb(@RequestParam("idlezione") int idlezione,@RequestParam("idesame") int idesame,Model model, HttpSession session){
		ProfessoreEsameLezione esamelezione = new ProfessoreEsameLezione();
		esamelezione.setIdesame(idesame);
		esamelezione.setIdlezione(idlezione);
		esamelezioneRepository.save(esamelezione);
	}
	
	/* -------------------------------------------------------------------------- */
	/*             	Request Map Visualizzazione voti alunni esame                 */
	/* -------------------------------------------------------------------------- */
	
	@GetMapping("/visualizzavoti")
	public String ModificaInfoLezione(@RequestParam("idesame") int idesame,@RequestParam("idclasse") int idclasse,Model model, HttpSession session){
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
	
	String ruolo=utente.getNomeRuolo(utente.getIdruolo());
	if(ruolo=="professore") {
		List<ProfessoreVotoStudente> lista_voti_esame = votostudenteRepository.GetVotiEsame(idesame, idclasse);
		model.addAttribute("lista_voti_esame",lista_voti_esame);
		return "/professore/visualizzavoti";
	}
	else {
		return "redirect:/"+ruolo;
	}
	}
	
	/* -------------------------------------------------------------------------- */
	/*             	Request Map Visualizzazione presenze alunni                   */
	/* -------------------------------------------------------------------------- */
	
	@GetMapping("/visualizzapresenze")
	public String VisualizzaPreseze(Model model, HttpSession session){
		Utente utente = (Utente) session.getAttribute("loggedUser");
		
		if (utente == null) {
			return "redirect:/";
		}
	
	String ruolo=utente.getNomeRuolo(utente.getIdruolo());
	if(ruolo=="professore") {
		int idProfessore = utenteRepository.GetIdProfessore(utente.getIdutente()); 
        Professore professore = professoreRepository.findByidprofessore(idProfessore);
        model.addAttribute("professore", professore);
        List<ProfessoreInfoLezione> lista_lezioni = infolezioneRepository.getClasseProfessore(idProfessore);
        model.addAttribute("lista_lezioni", lista_lezioni);
        model.addAttribute("username_utente", utente.getUsername());
		return "/professore/visualizzapresenze";
	}
	else {
		return "redirect:/"+ruolo;
	}
	}
	
	/* -------------------------------------------------------------------------- */
	/*             	Request Map Visualizzazione presenze alunni                   */
	/* -------------------------------------------------------------------------- */
	
	@GetMapping("/presenzelezione")
	public String VisualizzaPreseze(@RequestParam("idlezione") int idlezione,Model model, HttpSession session){
		Utente utente = (Utente) session.getAttribute("loggedUser");
		if (utente == null) {
			return "redirect:/";
		}
		String ruolo=utente.getNomeRuolo(utente.getIdruolo());
		if(ruolo=="professore") {
			List<ProfessorePresenzaStudenteInfo> presenze_lezione = presenzastudentiinfoRepository.GetPresenzeLezioni(idlezione);
			model.addAttribute("presenze_lezione",presenze_lezione);
			model.addAttribute("idlezione",idlezione);
            model.addAttribute("username_utente", utente.getUsername());
			return "/professore/presenzelezione";
		}
		else {
			return "redirect:/"+ruolo;
		}
	}
	
}
