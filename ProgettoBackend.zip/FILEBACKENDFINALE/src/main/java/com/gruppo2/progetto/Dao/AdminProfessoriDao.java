package com.gruppo2.progetto.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.AdminProfessore;

public interface AdminProfessoriDao extends CrudRepository<AdminProfessore, Long> {
        
}