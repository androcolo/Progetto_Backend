package com.gruppo2.progetto.Dao;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.ProfessoreInfoLezione;
import com.gruppo2.progetto.model.ProfessoreLezione;
import com.gruppo2.progetto.model.ProfessoreVotoStudente;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface ProfessoreVotoStudenteDao extends CrudRepository<ProfessoreVotoStudente, Long> {
	   
	/* -------------------------------------------------------------------------- */
	/*                         PRESA VOTI PER ESAME ALUNNI                        */
	/* -------------------------------------------------------------------------- */
    
    @Query(value = "SELECT studenti.idstudente,nome,cognome,voto FROM progetto_backend.voti_esami\r\n"
    		+ "INNER JOIN studenti on studenti.idstudente = voti_esami.idstudente\r\n"
    		+ "WHERE idesame = :idesame AND idclasse = :idclasse ;",nativeQuery = true)
    public List<ProfessoreVotoStudente> GetVotiEsame(int idesame,int idclasse);
    
}