package com.gruppo2.progetto.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
public class ProfessorePresenzaStudenteInfo {
	
	public ProfessorePresenzaStudenteInfo() {};
	
	public ProfessorePresenzaStudenteInfo(int idstudente, String ritardo, String uscita_anticipata, @NotNull String nome,
			@NotNull String cognome, @NotNull String data_nascita, @NotNull char sesso) {
		super();
		this.idstudente = idstudente;
		this.ritardo = ritardo;
		this.uscita_anticipata = uscita_anticipata;
		this.nome = nome;
		this.cognome = cognome;
		this.data_nascita = data_nascita;
		this.sesso = sesso;
	}

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    public int idstudente;
	
	public String ritardo;
	
	public String uscita_anticipata;
	
	@NotNull
	public String nome;
	
	@NotNull
	public String cognome;
	
	@NotNull
	public String data_nascita;
	
	@NotNull
	public char sesso;
	
}
