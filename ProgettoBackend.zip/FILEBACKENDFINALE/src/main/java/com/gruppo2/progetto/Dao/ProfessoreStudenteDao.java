package com.gruppo2.progetto.Dao;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.ProfessoreInfoLezione;
import com.gruppo2.progetto.model.ProfessoreLezione;
import com.gruppo2.progetto.model.ProfessoreStudente;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface ProfessoreStudenteDao extends CrudRepository<ProfessoreStudente, Long> {
	
	/* -------------------------------------------------------------------------- */
	/*                          PRESA ALUNNI DI UNA CLASSE                        */
	/* -------------------------------------------------------------------------- */
    
    @Query(value = "SELECT studenti.idstudente,studenti.nome,studenti.cognome,studenti.data_nascita,studenti.sesso,studenti.idutente,studenti.idclasse FROM progetto_backend.studenti\r\n"
    		+ "INNER JOIN classi on classi.idclasse = studenti.idclasse\r\n"
    		+ "WHERE studenti.idclasse=:idclasse",nativeQuery = true)
    public List<ProfessoreStudente> getAlunniClasse(int idclasse);
    
}