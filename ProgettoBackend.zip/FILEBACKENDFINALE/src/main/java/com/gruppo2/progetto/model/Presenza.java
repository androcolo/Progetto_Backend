package com.gruppo2.progetto.model;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
public class Presenza {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	public String idlezione;
	public String nome_modulo;
	public String nome_lezione;
	public String idstudente;
	public String data_ora;
	public String ritardo;
	public String uscita_anticipata;
	public Presenza() {}
	public Presenza(String idlezione,String nome_modulo,String nome_lezione, String idstudente,String data_ora,String ritardo,String uscita_anticipata) {
		super();
		this.idlezione = idlezione;
		this.nome_lezione = nome_modulo;
		this.nome_lezione = nome_lezione;
		this.idstudente = idstudente;
		this.data_ora = data_ora;
		this.ritardo = ritardo;
		this.uscita_anticipata = uscita_anticipata;
	}
	
}
