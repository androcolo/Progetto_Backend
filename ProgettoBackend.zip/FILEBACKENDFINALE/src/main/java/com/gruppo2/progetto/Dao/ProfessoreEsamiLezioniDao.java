package com.gruppo2.progetto.Dao;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.ProfessoreEsameLezione;
import com.gruppo2.progetto.model.ProfessorePresenza;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface ProfessoreEsamiLezioniDao extends CrudRepository<ProfessoreEsameLezione, Long> {


	/* -------------------------------------------------------------------------- */
	/*                         CONTROLLO ESISTENZA ESAME                          */
	/* -------------------------------------------------------------------------- */
    
    @Query(value = "SELECT * FROM progetto_backend.esami_lezioni\r\n"
    		+ "WHERE idlezione = :idlezione and idesame = :idesame ;",nativeQuery = true)
    public List<ProfessoreEsameLezione> ControllEsame(int idlezione,int idesame);
}