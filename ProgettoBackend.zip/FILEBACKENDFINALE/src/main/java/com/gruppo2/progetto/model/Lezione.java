package com.gruppo2.progetto.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Entity
@Table(name = "lezioni")
public class Lezione {
	
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int idlezione;
    
	@NotNull(message = "il nome della lezione deve essere inserito")
	String nome_lezione;
	
	@NotNull(message = "la descrizione deve essere inserita")
	String descrizione;
    
	@NotNull(message = "la data deve essere inserita")
	Timestamp data_ora;
	
	@NotNull(message = "il modulo deve essere inserito")
	int idmodulo;
	
	@NotNull(message = "la classe deve essere inserita")
	int idclasse;
	
	public Lezione() {
	}
	
	public Lezione(int idlezione,String nome_lezione,String descrizione,Timestamp data_ora,
			int idmodulo,int idclasse) {
		
		this.idlezione = idlezione;
		this.nome_lezione = nome_lezione;
		this.descrizione = descrizione;
		this.data_ora = data_ora;
		this.idmodulo = idmodulo;
		this.idclasse = idclasse;
	}

	public int getIdlezione() {
		return idlezione;
	}

	public void setIdlezione(int idlezione) {
		this.idlezione = idlezione;
	}

	public String getNome_lezione() {
		return nome_lezione;
	}

	public void setNome_lezione(String nome_lezione) {
		this.nome_lezione = nome_lezione;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public Timestamp getData_ora() {
		return data_ora;
	}

	public void setData_ora(Timestamp data_ora) {
		this.data_ora = data_ora;
	}

	public int getIdmodulo() {
		return idmodulo;
	}

	public void setIdmodulo(int idmodulo) {
		this.idmodulo = idmodulo;
	}

	public int getIdclasse() {
		return idclasse;
	}

	public void setIdclasse(int idclasse) {
		this.idclasse = idclasse;
	}

	@Override
	public String toString() {
		return "Lezione [idlezione=" + idlezione + ", nome_lezione=" + nome_lezione + ", descrizione=" + descrizione
				+ ", data_ora=" + data_ora + ", idmodulo=" + idmodulo + ", idclasse=" + idclasse + "]";
	}
	
}
