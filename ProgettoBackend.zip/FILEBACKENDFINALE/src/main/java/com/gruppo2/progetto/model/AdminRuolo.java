package com.gruppo2.progetto.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "ruoli")
public class AdminRuolo {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int idruolo;
	
	@NotNull(message = "ruolo deve esser inserito")
	String ruolo;

	public int getIdruolo() {
		return idruolo;
	}

	public void setIdruolo(int idruolo) {
		this.idruolo = idruolo;
	}

	public String getRuolo() {
		return ruolo;
	}

	public void setRuolo(String ruolo) {
		this.ruolo = ruolo;
	}

	@Override
	public String toString() {
		return "Ruolo [idruolo=" + idruolo + ", ruolo=" + ruolo + "]";
	}
	
}
