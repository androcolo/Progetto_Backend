package com.gruppo2.progetto.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Entity
public class ProfessoreStudente {
	
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    public int idstudente;
    
	@NotNull(message = "il nome deve essere inserito")
	public String nome;
	
	@NotNull(message = "il cognome deve essere inserito")
	public String cognome;
	
	@NotNull(message = "la data di nascita deve essere inserita")
	public String data_nascita;
	
	@NotNull(message = "il sesso deve essere inserito")
	public char sesso;
	
	@NotNull(message = "l'utente deve essere inserito")
	public int idutente;
	
	@NotNull(message = "la classe deve essere inserita")
	public int idclasse;

	
	public ProfessoreStudente() {
	}
	
	public ProfessoreStudente(int idstudente,String nome,String cognome,String data_nascita,char sesso,int idutente,int idclasse) {
		this.idstudente = idstudente;
		this.nome = nome;
		this.cognome = cognome;
		this.data_nascita = data_nascita;
		this.sesso = sesso;
		this.idutente = idutente;
		this.idclasse = idclasse;
	}
	
}
