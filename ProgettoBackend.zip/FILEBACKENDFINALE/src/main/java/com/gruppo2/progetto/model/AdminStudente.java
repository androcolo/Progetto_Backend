package com.gruppo2.progetto.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Entity
@Table(name = "studenti")
public class AdminStudente {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int idstudente;
    
	@NotNull(message = "il nome deve essere inserito")
	String nome;
	
	@NotNull(message = "il cognome deve essere inserito")
	String cognome;
	
	@NotNull(message = "la data di nascita deve essere inserita")
	String data_nascita;
	
	@NotNull(message = "il sesso deve essere inserito")
	char sesso;
	
	@NotNull(message = "l'utente deve essere inserito")
	int idutente;
	
	@NotNull(message = "la classe deve essere inserita")
	int idclasse;

	
	public AdminStudente() {
	}
	
	public AdminStudente(int idstudente,String nome,String cognome,String data_nascita,char sesso,int idutente,int idclasse) {
		this.idstudente = idstudente;
		this.nome = nome;
		this.cognome = cognome;
		this.data_nascita = data_nascita;
		this.sesso = sesso;
		this.idutente = idutente;
		this.idclasse = idclasse;
	}
	
	
	public int getIdstudente() {
		return idstudente;
	}

	public void setIdstudente(int idstudente) {
		this.idstudente = idstudente;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getData_nascita() {
		return data_nascita;
	}

	public void setData_nascita(String data_nascita) {
		this.data_nascita = data_nascita;
	}

	public char getSesso() {
		return sesso;
	}

	public void setSesso(char sesso) {
		this.sesso = sesso;
	}

	public int getIdutente() {
		return idutente;
	}

	public void setIdutente(int idutente) {
		this.idutente = idutente;
	}

	public int getIdclasse() {
		return idclasse;
	}

	public void setIdclasse(int idclasse) {
		this.idclasse = idclasse;
	}

	@Override
	public String toString() {
		return "Studente [idstudente=" + idstudente + ", nome=" + nome + ", cognome=" + cognome + ", data_nascita="
				+ data_nascita + ", sesso=" + sesso + ", idutente=" + idutente + ", idclasse=" + idclasse + "]";
	}
}
