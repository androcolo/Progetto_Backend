package com.gruppo2.progetto.Dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.AdminCategoria;
import com.gruppo2.progetto.model.AdminModulo;
import com.gruppo2.progetto.model.Utente;

public interface AdminDao extends CrudRepository<Utente, Long> {
	
}
