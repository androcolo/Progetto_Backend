package com.gruppo2.progetto.Dao;
import java.util.List;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.AdminLezione;



// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
public interface AdminLezioniDao extends CrudRepository<AdminLezione, Long> {
    
    /* -------------------------------------------------------------------------- */
    /*                       PRESA DATI LEZIONE                          		  */
    /* -------------------------------------------------------------------------- */
   
    @Query(value = "SELECT * FROM progetto_backend.lezioni\r\n"
            + "WHERE idlezione = :idlezione ;",nativeQuery = true)
    public AdminLezione getLezione(int idlezione);
    
}