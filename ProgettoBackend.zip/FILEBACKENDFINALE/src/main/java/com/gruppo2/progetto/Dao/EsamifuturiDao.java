package com.gruppo2.progetto.Dao;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.gruppo2.progetto.model.Esamifuturi;
import com.gruppo2.progetto.model.Voti;

public interface EsamifuturiDao extends CrudRepository<Esamifuturi, Long> {
    @Query(value="SELECT esami.idesame,data_ora,nome_esame,esami.descrizione,nome_modulo,nome,cognome FROM progetto_backend.lezioni\r\n"
    		+ "    inner join esami_lezioni on esami_lezioni.idlezione=lezioni.idlezione\r\n"
    		+ "    inner join esami on esami.idesame=esami_lezioni.idesame\r\n"
    		+ "    inner join moduli on moduli.idmodulo=lezioni.idmodulo\r\n"
    		+ "    inner join professori on professori.idprofessore=moduli.idprofessore\r\n"
    		+ "    where idclasse=:classe AND data_ora>NOW();",nativeQuery = true)
	public List<Esamifuturi> esamiFuturiStudente(int classe);
}