var mainApp={};
var nameToDisplay="";
var uIdApp="";
(function(){
    var firebase=app_fireBase;
    firebase.auth().onAuthStateChanged(function(user){
    if(user){
        nameToDisplay=user.displayName
        uid=user.uid;
        uIdApp=uid
        startWebsite();
    }
    else{
        uid=null;
        window.location.replace("login.html");
        }
    });
function logOut(){
        firebase.auth().signOut();
    }
mainApp.logOut=logOut;
})()
let cryptoList=[]
let url='https://api.coingecko.com/api/v3/coins/markets?vs_currency=Eur&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=1m'

function startWebsite(){
    $.ajax({
    url,
    method:'GET',
    dataType:"json",
    success:function(data){
        cryptoList=data
        console.log(data)
        console.log(uid)
    }})
}